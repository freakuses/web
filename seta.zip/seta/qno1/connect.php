<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studen_info";

$name = $_POST['name'];
$address = $_POST['address'];
$contact = $_POST['contact'];
$email = $_POST['email'];
$about = $_POST['about'];


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO `users` (`name`, `address`, `email`, `contact`, `about`) 
VALUES ( '$name', '$address', '$email', '$contact', '$about');";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>